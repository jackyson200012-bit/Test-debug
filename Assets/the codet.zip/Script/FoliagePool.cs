using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Object pooling for foliage instances, managed by ChunkManager alongside existing ChunkPool.
/// Reuses pooled GameObjects instead of Instantiate/Destroy to avoid GC allocations during streaming.
/// </summary>
public class FoliagePool
{
    private static FoliagePool instance;
    
    public static FoliagePool Instance
    {
        get => instance ??= new FoliagePool();
        set => instance = value;
    }

    private readonly List<GameObject> pooledObjects = new List<GameObject>();
    private int activeCount;

    /// <summary>
    /// Retrieves a pooled foliage GameObject for the given placement data, or creates one if pool is empty.
    /// </summary>
    public GameObject GetPooledInstance(Vector3 worldPosition, int foliageType)
    {
        // Dequeue from pool first (zero allocation path)
        if (pooledObjects.Count > 0)
        {
            var instance = pooledObjects[pooledObjects.Count - 1];
            
            // Clear and disable before returning to pool
            foreach (Transform child in instance.transform)
            {
                child.gameObject.SetActive(false);
            }

            instance.SetActive(false);
            return instance;
        }

        // Create new instance from prefab when pool is empty (fallback)
        GameObject prefab = null;
        if (foliageType == 0 && settings.fruitTree != null)
            prefab = Instantiate(settings.fruitTree, Vector3.zero, Quaternion.identity);
        else if (settings.grass01 != null)
            prefab = Instantiate(settings.grass01, Vector3.zero, Quaternion.identity);
        
        if (prefab == null) return null; // No valid prefab available
        
        pooledObjects.Add(prefab);
        prefab.SetActive(false);
        return prefab;
    }

    /// <summary>
    /// Returns an object to the pool for reuse (no Instantiate/Destroy).
    /// </summary>
    public void ReleaseInstance(GameObject instance)
    {
        if (instance == null) return;

        // Clear and disable before returning to pool
        foreach (Transform child in instance.transform)
        {
            child.gameObject.SetActive(false);
        }

        instance.SetActive(false);
        pooledObjects.Add(instance);
    }

    private WorldSettings settings;

    /// <summary>
    /// Sets the WorldSettings reference (called from ChunkManager after initialization).
    /// </summary>
    public void SetWorldSettings(WorldSettings s) => settings = s;

    /// <summary>
    /// Returns the current active count of foliage instances.
    /// </summary>
    public int GetActiveCount() => activeCount;

    /// <summary>
    /// Gets total pool size including inactive objects.
    /// </summary>
    public int GetPoolSize() => pooledObjects.Count;
}