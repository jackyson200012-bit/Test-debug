using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Pools Chunk instances so streaming an infinite world doesn't
/// constantly Instantiate/Destroy GameObjects (avoids GC spikes).
/// </summary>
public class ChunkPool
{
    private readonly Stack<Chunk> pool = new Stack<Chunk>();
    private readonly Transform parent;
    private readonly WorldSettings settings;

    public ChunkPool(Transform parent, WorldSettings settings)
    {
        this.parent = parent;
        this.settings = settings;
    }

    public Chunk Get(Vector2Int coord, TerrainGenerator terrainGenerator)
    {
        Chunk chunk;

        if (pool.Count > 0)
        {
            chunk = pool.Pop();
            chunk.Activate(coord, settings, terrainGenerator);
        }
        else
        {
            chunk = new Chunk(coord, parent, settings, terrainGenerator);
        }

        return chunk;
    }

    public void Release(Chunk chunk)
    {
        chunk.Deactivate();
        pool.Push(chunk);
    }
}
