using UnityEngine;

[CreateAssetMenu(fileName = "WorldSettings", menuName = "World/World Settings")]
public class WorldSettings : ScriptableObject
{
    [Header("World")]

    public int seed = 12345;

    [Min(16)]
    public int chunkSize = 64;
    public Material terrainMaterial;

    [Min(2)]
    public int verticesPerLine = 65;

    [Header("Noise")]

    public float noiseScale = 0.03f;

    public float heightMultiplier = 15f;

    public int octaves = 4;

    [Range(0f, 1f)]
    public float persistence = 0.5f;

    public float lacunarity = 2f;

    public Vector2 noiseOffset;

    [Header("Streaming")]

    [Range(1, 10)]
    public int viewDistance = 5;

    public bool generateCollision;

    [Header("Terrain Texture")]

    public TerrainLayer groundLayer;


    [Header("Grass")]

    public GameObject grass01;
    public GameObject grass02;

[Range(0, 100)]
public int grassChance = 50;

/// <summary>Minimum height for terrain to be considered valid for foliage placement. Terrain below this height is skipped during foliage generation.</summary>
[Min(0f)]
public float terrainHeightThreshold = 0f;


[Header("Trees")]

    public GameObject fruitTree;

    [Min(0)]
    public int treesPerChunk = 200;

/// <summary>Multiplier applied to noise values when computing foliage density. Higher values produce denser foliage.</summary>
[Range(0.1f, 5.0f)]
public float foliageDensityMultiplier = 1.5f;

/// <summary>Normalized threshold (0-1) for minimum noise value required for a placement point to spawn foliage.</summary>
[Range(0.0f, 1.0f)]
public float spawnThreshold = 0.35f;

/// <summary>Offset added to the deterministic hash used in world-space seed derivation — shifts placement patterns across chunks.</summary>
public float hashOffset = 12345.789f;

/// <summary>Multiply factor for the deterministic hash used in noise/seed generation — controls hash distribution spread. Default is 1.0 to keep values flowing directly into Hash().</summary>
public float hashMultiplier = 1f;

/// <summary>World-level water level (negative values are valid). Samples below this height are skipped during foliage generation.</summary>
[Range(-50f, 10f)]
public float waterLevel = -5f;
}
