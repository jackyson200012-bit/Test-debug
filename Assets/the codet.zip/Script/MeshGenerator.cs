using System.Collections.Generic;
using UnityEngine;

public static class MeshGenerator
{
    public static Mesh Generate(HeightMap heightMap, WorldSettings settings)
    {
        int vertsPerLine = settings.verticesPerLine;
        int chunkSize = settings.chunkSize;

        Vector3[] vertices = new Vector3[vertsPerLine * vertsPerLine];
        Vector2[] uvs = new Vector2[vertices.Length];
        List<int> triangles = new List<int>((vertsPerLine - 1) * (vertsPerLine - 1) * 6);

        float vertexSpacing = (float)chunkSize / (vertsPerLine - 1);

        int vertexIndex = 0;

        for (int z = 0; z < vertsPerLine; z++)
        {
            for (int x = 0; x < vertsPerLine; x++)
            {
                float height = heightMap.heights[x, z];

                vertices[vertexIndex] = new Vector3(
                    x * vertexSpacing,
                    height,
                    z * vertexSpacing
                );

                uvs[vertexIndex] = new Vector2(
                    (float)x / (vertsPerLine - 1),
                    (float)z / (vertsPerLine - 1)
                );

                if (x < vertsPerLine - 1 && z < vertsPerLine - 1)
                {
                    int a = vertexIndex;
                    int b = vertexIndex + vertsPerLine;
                    int c = vertexIndex + vertsPerLine + 1;
                    int d = vertexIndex + 1;

                    triangles.Add(a);
                    triangles.Add(b);
                    triangles.Add(c);

                    triangles.Add(a);
                    triangles.Add(c);
                    triangles.Add(d);
                }

                vertexIndex++;
            }
        }

        Mesh mesh = new Mesh
        {
            name = "Terrain Chunk Mesh"
        };

        mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        mesh.SetVertices(vertices);
        mesh.SetTriangles(triangles, 0);
        mesh.SetUVs(0, uvs);
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();

        return mesh;
    }
}