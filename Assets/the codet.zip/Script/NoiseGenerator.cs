using UnityEngine;

public class NoiseGenerator
{
    private readonly WorldSettings settings;
    
    public NoiseGenerator(WorldSettings settings)
    {
        this.settings = settings;
    }

    public HeightMap GenerateHeightMap(Vector2Int chunkCoord)
    {
        int vertsPerLine = settings.verticesPerLine;
        int chunkSize = settings.chunkSize;
        float vertexSpacing = (float)chunkSize / (vertsPerLine - 1);
        
        float[,] heights = new float[vertsPerLine, vertsPerLine];
        
        float minHeight = float.MaxValue;
        float maxHeight = float.MinValue;

        for (int z = 0; z < vertsPerLine; z++)
        {
            for (int x = 0; x < vertsPerLine; x++)
            {
                float worldX = chunkCoord.x * chunkSize + x * vertexSpacing;
                float worldZ = chunkCoord.y * chunkSize + z * vertexSpacing;
                
                float height = SampleNoise(worldX, worldZ);
                heights[x, z] = height;

                if (height < minHeight) minHeight = height;
                if (height > maxHeight) maxHeight = height;
            }
        }

        return new HeightMap(heights, minHeight, maxHeight);
    }

    /// <summary>
    /// World-space deterministic fBm sample — uses Perlin directly on scaled coordinates.
    /// No PRNG offsets: each octave evaluates Perlin at (worldX * lacunarity^i, worldZ * lacunarity^i),
    /// guaranteeing smooth continuity across chunks and meaningful fractal structure.
    /// </summary>
    public float SampleWorldSpaceNoise(float worldX, float worldZ)
    {
        float amplitude = 1f;
        float frequency = 1f;
        float noiseHeight = 0f;

        for (int i = 0; i < settings.octaves; i++)
        {
            // Direct Perlin evaluation — deterministic from coordinates alone, smooth across chunks
            float sampleX = worldX * settings.noiseScale * frequency;
            float sampleZ = worldZ * settings.noiseScale * frequency;

            float perlin = Mathf.PerlinNoise(sampleX, sampleZ) * 2f - 1f;
            noiseHeight += perlin * amplitude;

            amplitude *= settings.persistence;
            frequency *= settings.lacunarity;
        }

        return noiseHeight * settings.foliageDensityMultiplier;
    }

    private float SampleNoise(float worldX, float worldZ)
    {
        // Identical algorithm to SampleWorldSpaceNoise but with height multiplier instead of foliage density.
        // This ensures the terrain field is exactly continuous with any world-space noise sampling at the same coordinates.
        float amplitude = 1f;
        float frequency = 1f;
        float noiseHeight = 0f;

        for (int i = 0; i < settings.octaves; i++)
        {
            float sampleX = worldX * settings.noiseScale * frequency;
            float sampleZ = worldZ * settings.noiseScale * frequency;

            float perlin = Mathf.PerlinNoise(sampleX, sampleZ) * 2f - 1f;
            noiseHeight += perlin * amplitude;

            amplitude *= settings.persistence;
            frequency *= settings.lacunarity;
        }

        return noiseHeight * settings.heightMultiplier;
    }

    /// <summary>
    /// Deterministic hash for placement decisions (e.g., foliage type selection).
    /// Incorporates WorldSettings.seed so different worlds produce different layouts.
    /// </summary>
    internal int Hash(float value)
    {
        // Mix in seed via XOR to ensure world-isolated determinism
        long result = ((long)(UnityEngine.Mathf.Abs(UnityEngine.Mathf.Floor(value * 609347520.0f))) ^ settings.seed);
        // Fold bits for good distribution across the full range
        result ^= (result >> 16);
        return (int)(result & ((1L << 30) - 1)); // 30-bit mask for variety
    }
}