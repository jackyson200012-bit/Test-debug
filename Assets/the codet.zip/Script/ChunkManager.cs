using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Loads/unloads chunks around a center coordinate (usually the player's
/// chunk position). Uses ChunkPool instead of Destroy/Instantiate.
/// Does NOT run every frame itself — WorldManager decides when to call
/// UpdateChunks, on a timer, so this stays cheap.
/// </summary>
public class ChunkManager
{
    private readonly WorldSettings settings;
    private readonly TerrainGenerator terrainGenerator;
    private readonly ChunkPool chunkPool;
    private readonly FoliagePool foliagePool;


    private readonly Dictionary<Vector2Int, Chunk> activeChunks =
        new Dictionary<Vector2Int, Chunk>();

    public ChunkManager(
        Transform parent,
        WorldSettings settings,
        TerrainGenerator terrainGenerator)
    {
        this.settings = settings;
        this.terrainGenerator = terrainGenerator;
        chunkPool = new ChunkPool(parent, settings);
        foliagePool = new FoliagePool(); // Initialize foliage pool for reuse
    }

    public void UpdateChunks(Vector2Int centerCoord)
    {
        HashSet<Vector2Int> neededCoords =
            GetCoordsInRange(centerCoord, settings.viewDistance);

        // Release chunks that are no longer within view distance
        List<Vector2Int> toRemove = null;
        foreach (var kvp in activeChunks)
        {
            if (!neededCoords.Contains(kvp.Key))
            {
                toRemove ??= new List<Vector2Int>();
                toRemove.Add(kvp.Key);
            }
        }

        if (toRemove != null)
        {
            foreach (var coord in toRemove)
            {
                chunkPool.Release(activeChunks[coord]);
                activeChunks.Remove(coord);
            }
        }

        // Get/activate chunks that are newly within view distance
        foreach (var coord in neededCoords)
        {
            if (!activeChunks.ContainsKey(coord))
            {
                Chunk chunk = chunkPool.Get(coord, terrainGenerator);
                activeChunks[coord] = chunk;
            }
        }
    }

    private HashSet<Vector2Int> GetCoordsInRange(Vector2Int center, int radius)
    {
        HashSet<Vector2Int> result = new HashSet<Vector2Int>();

        for (int x = -radius; x <= radius; x++)
        {
            for (int z = -radius; z <= radius; z++)
            {
                result.Add(new Vector2Int(center.x + x, center.y + z));
            }
        }

        return result;
    }
}
