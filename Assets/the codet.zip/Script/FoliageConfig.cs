using UnityEngine;

[CreateAssetMenu(fileName = "FoliageConfig", menuName = "World/Foliage Configuration")]
public class FoliageConfig : ScriptableObject
{
    [Header("Placement")]
    public float densityPerUnitArea = 1.0f;
    public float noiseThreshold = 0.3f;

    [Header("Noise Parameters")]
    public int octaves = 4;

    [Range(0f, 1f)]
    public float persistence = 0.5f;

    public float lacunarity = 2f;

    [Header("Scale & Offset")]
    public Vector2 noiseOffset;
    public float heightMultiplier = 1.0f;
}