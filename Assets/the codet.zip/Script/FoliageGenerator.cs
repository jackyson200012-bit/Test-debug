using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Produces foliage placement data points for a given chunk based on world-space noise sampling.
/// Does NOT instantiate GameObjects — only generates pure data for FoliagePool to consume.
/// </summary>
public class FoliageGenerator
{
    private readonly WorldSettings settings;
    private readonly NoiseGenerator noiseGenerator;

    public FoliageGenerator(WorldSettings settings)
    {
        this.settings = settings;
        this.noiseGenerator = new NoiseGenerator(settings);
    }

    /// <summary>
    /// Generates placement points for the given chunk coordinates.
    /// Uses world-space noise (not per-chunk RNG) to ensure continuity across chunk borders.
    /// </summary>
    public List<FoliageGenerator.PlacementPoint> Generate(Vector2Int chunkCoord, HeightMap heightMap)
    {
        var placementPoints = new List<FoliageGenerator.PlacementPoint>();

        // Sample world-space coordinates for the chunk bounds
        int chunkX = chunkCoord.x;
        int chunkZ = chunkCoord.y; // Vector2Int uses y, not z
        
        float minX = (float)chunkX * settings.chunkSize;
        float minZ = (float)chunkZ * settings.chunkSize;
        float maxX = ((float)(chunkX + 1)) * settings.chunkSize;
        float maxZ = ((float)(chunkZ + 1)) * settings.chunkSize;

        // Sample noise at regular intervals across the chunk
        float samplesPerLine = Mathf.Max(1.0f, settings.chunkSize / 4.0f);

        for (float i = 0; i < settings.chunkSize; i += samplesPerLine)
        {
            float worldX = minX + i;

            for (float j = 0; j < settings.chunkSize; j += samplesPerLine)
            {
                float worldZ = minZ + j;

                // Sample world-space noise (deterministic, seed-based)
                float noiseValue = noiseGenerator.SampleWorldSpaceNoise(worldX, worldZ);

                float terrainHeight = heightMap.GetHeightAtWorldPosition(worldX, worldZ);

                if (terrainHeight < settings.waterLevel)
                {
                    continue;
                }

                float adjustedNoise = noiseValue * settings.foliageDensityMultiplier + 0.5f;

                if (adjustedNoise >= settings.spawnThreshold)
                {
                    // Delegate to shared Hash() in NoiseGenerator for consistency — same seed mixing, world-isolated determinism
                    int hashValue = noiseGenerator.Hash(worldX * 0.5f + worldZ * 0.3f);
                    int foliageType = Mathf.Abs(hashValue % 2);

                    placementPoints.Add(new FoliageGenerator.PlacementPoint
                    {
                        WorldPosition = new Vector3(worldX, terrainHeight + 1f, worldZ),
                        ChunkPosition = new Vector2Int(
                            (int)((worldX - minX) / settings.chunkSize * settings.verticesPerLine),
                            (int)((worldZ - minZ) / settings.chunkSize * settings.verticesPerLine)
                        ),
                        FoliageType = foliageType,
                        DensityWeight = adjustedNoise,
                        RandomSeed = hashValue // Deterministic per-point seed for variation
                    });
                }
            }
        }

        return placementPoints;
    }

    /// <summary>
    /// Represents a single foliage placement point (pure data — no GameObjects).
    /// </summary>
    public struct PlacementPoint
    {
        public Vector3 WorldPosition;
        public Vector2Int ChunkPosition; // Local to chunk's vertex grid
        public int FoliageType;         // 0 = tree, 1 = grass
        public float DensityWeight;     // Noise-based weight for ordering/priority
        public int RandomSeed;          // Deterministic per-point seed for variation

        /// <summary>
        /// Returns the world-space coordinates of this placement point.
        /// </summary>
        public Vector3 ToWorldPosition() => WorldPosition;

        /// <summary>
        /// Validates that all required fields are properly set and values are reasonable.
        /// </summary>
        public bool IsValid()
        {
            // Check if world position is at or near origin (default/uninitialized)
            if ((WorldPosition.x == 0f && WorldPosition.y == 0f && WorldPosition.z == 0f) || 
                Vector3.Distance(WorldPosition, Vector3.zero) < 0.01f)
            {
                return false;
            }

            // Check foliage type is valid (should be 0 or 1)
            if (FoliageType != 0 && FoliageType != 1)
            {
                return false;
            }

            // All critical fields set - valid point
            return true;
        }
    }
}