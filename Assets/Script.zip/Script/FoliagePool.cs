using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Object pooling for foliage instances, managed by ChunkManager alongside existing ChunkPool.
/// Reuses pooled GameObjects instead of Instantiate/Destroy to avoid GC allocations during streaming.
/// </summary>
public class FoliagePool
{
    private static FoliagePool instance;
    
    public static FoliagePool Instance
    {
        get => instance ??= new FoliagePool();
        set => instance = value;
    }

    private readonly List<GameObject> pooledObjects = new List<GameObject>();
    private int activeCount;

    /// <summary>
    /// Retrieves a pooled foliage GameObject for the given placement data, or creates one if pool is empty.
    /// </summary>
    public GameObject GetPooledInstance(Vector3 worldPosition, int foliageType)
    {
        // Dequeue from pool first (zero allocation path)
        if (pooledObjects.Count > 0)
        {
            var instance = pooledObjects[pooledObjects.Count - 1];
            
            // Clear and disable before returning to pool
            foreach (Transform child in instance.transform)
            {
                child.gameObject.SetActive(false);
            }

            instance.SetActive(false);
            return instance;
        }

        // Create new instance when pool exhausted - handled by ChunkManager's activation flow
        return null;
    }

    /// <summary>
    /// Returns an object to the pool for reuse (no Instantiate/Destroy).
    /// </summary>
    public void ReleaseInstance(GameObject instance)
    {
        if (instance == null) return;

        // Clear and disable before returning to pool
        foreach (Transform child in instance.transform)
        {
            child.gameObject.SetActive(false);
        }

        instance.SetActive(false);
        pooledObjects.Add(instance);
    }

    /// <summary>
    /// Returns the current active count of foliage instances.
    /// </summary>
    public int GetActiveCount() => activeCount;

    /// <summary>
    /// Gets total pool size including inactive objects.
    /// </summary>
    public int GetPoolSize() => pooledObjects.Count;
}