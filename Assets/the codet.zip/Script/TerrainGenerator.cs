using UnityEngine;

public class TerrainGenerator
{
    private readonly NoiseGenerator noiseGenerator;
    private readonly WorldSettings settings;

    public TerrainGenerator(WorldSettings settings)
    {
        this.settings = settings;
        noiseGenerator = new NoiseGenerator(settings);
    }

    public HeightMap GenerateHeightMap(Vector2Int chunkCoord)
    {
        return noiseGenerator.GenerateHeightMap(chunkCoord);
    }
}