using System.Collections.Generic;
using UnityEngine;

public struct FoliageData
{
    public List<Vector3> placementPoints;
    public int[] typeIndices;
    public float[] densityWeights;

    public static readonly FoliageData Empty = new FoliageData();

    public bool IsEmpty => placementPoints == null || placementPoints.Count == 0;
}