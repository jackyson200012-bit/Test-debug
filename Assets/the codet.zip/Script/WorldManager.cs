using UnityEngine;

/// <summary>
/// Owns WorldSettings and the player reference. Tracks the player's
/// chunk coordinate and tells ChunkManager to update on a timer
/// (not every frame) rather than checking distance constantly.
/// </summary>
public class WorldManager : MonoBehaviour
{
    [SerializeField] private WorldSettings settings;
    [SerializeField] private Transform player;
    [SerializeField] private float updateInterval = 0.2f;

    private ChunkManager chunkManager;
    private TerrainGenerator terrainGenerator;

    private float timer;
    private Vector2Int lastCenterCoord;

    private void Awake()
    {
        if (player == null)
        {
            player = GameObject.FindGameObjectWithTag("Player").transform;
        }

        terrainGenerator = new TerrainGenerator(settings);
        chunkManager = new ChunkManager(transform, settings, terrainGenerator);
    }

    private void Start()
    {
        lastCenterCoord = GetPlayerChunkCoord();
        chunkManager.UpdateChunks(lastCenterCoord);
    }

    private void Update()
    {
        timer += Time.deltaTime;

        if (timer < updateInterval)
            return;

        timer = 0f;

        Vector2Int currentCoord = GetPlayerChunkCoord();

        if (currentCoord != lastCenterCoord)
        {
            lastCenterCoord = currentCoord;
            chunkManager.UpdateChunks(currentCoord);
        }
    }

    private Vector2Int GetPlayerChunkCoord()
    {
        int x = Mathf.FloorToInt(player.position.x / settings.chunkSize);
        int z = Mathf.FloorToInt(player.position.z / settings.chunkSize);
        return new Vector2Int(x, z);


    }
}
