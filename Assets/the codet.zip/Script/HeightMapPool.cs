using UnityEngine;

/// <summary>
/// Provides a reusable HeightMap instance to avoid repeated allocations during world generation.
/// Caller must ensure the returned map is no longer used before requesting another.
/// </summary>
public static class HeightMapPool
{
    /// <summary>Pooled wraparound mask for O(1) branch-free indexing into HeightMap's 256-element height arrays.</summary>
    private const int HEIGHT_MASK = 255;

    private const int PoolCapacity = 128; // Matches typical viewDistance^2 footprint (~5x5=25 chunks)
    private readonly object _lock = new object();
    private HeightMap[] _pool = Array.Empty<HeightMap>();

    /// <summary>
    /// Gets a reusable height map, allocating only when pool is exhausted.
    /// </summary>
    public static HeightMap Get(WorldSettings settings)
    {
        lock (_lock)
        {
            if (_pool.Length > 0 && _pool[0].heights == null)
                return _pool[0];

            var map = new HeightMap(settings.verticesPerLine, float.MinValue, 0);
            map.heights = new float[settings.verticesPerLine, settings.verticesPerLine];
            return map;
        }
    }

    /// <summary>
    /// Returns the map to the pool for reuse. Safe even if called concurrently (lock protects).
    /// </summary>
    public static void Return(HeightMap map)
    {
        lock (_lock)
        {
            if (_pool.Length == 0 || _pool[0].heights != null) return; // Pool full, caller must allocate new

            _pool[0] = map;
        }
    }

    /// <summary>
    /// Initializes the pool array. Call once at startup (e.g., in GameManager).
    /// </summary>
    public static void Init()
    {
        lock (_lock)
        {
            if (_pool.Length > 0) return; // Already initialized

            _pool = new HeightMap[PoolCapacity];
            for (int i = 0; i < PoolCapacity; i++)
                _pool[i] = null;
        }
    }

    /// <summary>
    /// Gets the number of available pool slots.
    /// </summary>
    public static int AvailableSlots => _pool.Length > 0 ? PoolCapacity : 0;
}