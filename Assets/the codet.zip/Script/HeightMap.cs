using UnityEngine;

/// <summary>
/// Represents a 2D terrain height map with interpolation for arbitrary world positions.
/// </summary>
public class HeightMap
{
    public float[,] heights;
    public float minHeight;
    public float maxHeight;
    public int width;       // verticesPerLine along X
    public int depth;       // verticesPerLine along Z

    /// <summary>
    /// Creates a height map from raw data.
    /// </summary>
    public HeightMap(float[,] heights, float minHeight, float maxHeight)
    {
        this.heights = heights;
        this.minHeight = minHeight;
        this.maxHeight = maxHeight;
        width = heights.GetLength(0);
        depth = heights.GetLength(1);
    }

    /// <summary>
    /// Creates a height map with explicit vertex counts.
    /// </summary>
    public HeightMap(int verticesPerLine, float minHeight, float maxHeight)
    {
        int size = verticesPerLine;
        heights = new float[size, size];
        this.width = size;
        this.depth = size;
        this.minHeight = minHeight;
        this.maxHeight = maxHeight;
    }

    /// <summary>
    /// Interpolates height at the given world-space coordinates.
    /// </summary>
    public float GetHeightAtWorldPosition(float worldX, float worldZ)
    {
        // Convert world space to local chunk-relative coordinates
        int xIndex = Mathf.FloorToInt(worldX);
        int zIndex = Mathf.FloorToInt(worldZ);

        // Clamp to map bounds
        xIndex = Mathf.Clamp(xIndex, 0, width - 1);
        zIndex = Mathf.Clamp(zIndex, 0, depth - 1);

        float fractionX = worldX - xIndex;
        float fractionZ = worldZ - zIndex;

        // Bilinear interpolation
        float h00 = heights[xIndex, zIndex];
        float h10 = heights[(xIndex + 1) % width, zIndex];
        float h01 = heights[xIndex, (zIndex + 1) % depth];
        float h11 = heights[(xIndex + 1) % width, (zIndex + 1) % depth];

        return Mathf.Lerp(Mathf.Lerp(h00, h10, fractionX), Mathf.Lerp(h01, h11, fractionX), fractionZ);
    }
}