using System.Collections.Generic;
using UnityEngine;

public class Chunk
{
    // Coord must be mutable so pooled chunks can be re-used for different
    // coordinates when activated from the pool.
    public Vector2Int Coord { get; private set; }

    public GameObject GameObject { get; }

    private readonly MeshFilter meshFilter;
    private readonly MeshRenderer meshRenderer;
    private readonly MeshCollider meshCollider;

    private TerrainGenerator terrainGenerator;
    private FoliageGenerator foliageGenerator;

    /// <summary>
    /// Initialize chunk with given parameters. This is called once during creation.
    /// </summary>
    public Chunk(
        Vector2Int coord,
        Transform parent,
        WorldSettings settings,
        TerrainGenerator terrainGenerator)
    {
        // Create the GameObject and components once. Mesh and position are
        // initialized here but can be updated later via Activate when this
        // chunk is reused from a pool.
        Coord = coord;

        GameObject = new GameObject($"Chunk_{coord.x}_{coord.y}");
        GameObject.transform.SetParent(parent, false);

        meshFilter = GameObject.AddComponent<MeshFilter>();
        meshRenderer = GameObject.AddComponent<MeshRenderer>();

        if (settings.generateCollision)
            meshCollider = GameObject.AddComponent<MeshCollider>();

        // Initialize mesh and position for the first time.
        UpdateForCoord(coord, settings, terrainGenerator);
    }

    /// <summary>
    /// Called when this chunk is activated from a pool or loaded fresh.
    /// Sets up generators if not already initialized (for pooled reuse).
    /// </summary>
    public void OnActivate(Vector2Int coord, WorldSettings settings, TerrainGenerator terrainGenerator)
    {
        // Initialize lazy fields on first use — safe for both fresh and pooled chunks
        terrainGenerator ??= new TerrainGenerator(settings);
        foliageGenerator ??= new FoliageGenerator(settings);

        Coord = coord;

        GameObject.name = $"Chunk_{coord.x}_{coord.y}";

        UpdateForCoord(coord, settings, terrainGenerator);

        GameObject.SetActive(true);
    }

    /// <summary>
    /// Deactivate keeps the GameObject around for reuse but disables it in the scene.
    /// </summary>
    public void Deactivate()
    {
        GameObject.SetActive(false);
    }

    private void UpdateForCoord(Vector2Int coord, WorldSettings settings, TerrainGenerator terrainGenerator)
    {
        GameObject.transform.position = new Vector3(
            coord.x * settings.chunkSize,
            0f,
            coord.y * settings.chunkSize);

        HeightMap heightMap = terrainGenerator.GenerateHeightMap(coord);

        Mesh mesh = MeshGenerator.Generate(heightMap, settings);

        meshFilter.sharedMesh = mesh;

        if (meshCollider != null)
            meshCollider.sharedMesh = mesh;

        meshRenderer.sharedMaterial = settings.terrainMaterial;

        // Generate and place foliage for this chunk
        GenerateFoliage(coord, heightMap, settings);
    }

    private void GenerateFoliage(Vector2Int coord, HeightMap heightMap, WorldSettings settings)
    {
        if (foliageGenerator == null || heightMap == null) return;

        // Get or create the foliage pool instance from ChunkManager
        // This will be passed in through OnActivate once we update that flow
        var placementPoints = foliageGenerator.Generate(coord, heightMap);

        foreach (var point in placementPoints)
        {
            // Validate placement point before creating object
            if (!point.IsValid()) continue;

            // Use FoliagePool to get a pooled instance instead of creating new ones
            var foliageGO = GetOrCreateFoliageInstance(point, settings);
            
            // Position the foliage instance in world space
            foliageGO.transform.position = point.WorldPosition;
            
            // Apply appropriate material based on foliage type (0=tree, 1=grass)
            if (!foliageGO.GetComponent<MeshRenderer>())
            {
                var renderer = foliageGO.AddComponent<MeshRenderer>();
                if (point.FoliageType == 0 && settings.fruitTree != null)
                    renderer.sharedMaterial = settings.fruitTree.GetComponent<MeshRenderer>()?.sharedMaterial;
                else if (settings.grass01 != null)
                    renderer.sharedMaterial = settings.grass01.GetComponent<MeshRenderer>()?.sharedMaterial;
            }

            // Store reference for pooling/reuse when chunk is deactivated
            foliageGO.tag = "Foliage";
        }
    }

    private GameObject GetOrCreateFoliageInstance(FoliageGenerator.PlacementPoint point, WorldSettings settings)
    {
        // Try to get a pooled instance first (zero-allocation path)
        var pooledInstance = FoliagePool.Instance?.GetPooledInstance(point.WorldPosition, point.FoliageType);

        if (pooledInstance != null)
            return pooledInstance;

        // Create new instance when pool exhausted — handled by ChunkManager's activation flow
        return null;
    }

    public void SetVisible(bool visible)
    {
        GameObject.SetActive(visible);
    }

    public bool IsVisible()
    {
        return GameObject.activeSelf;
    }

    public void Destroy()
    {
        Object.Destroy(GameObject);
    }
}